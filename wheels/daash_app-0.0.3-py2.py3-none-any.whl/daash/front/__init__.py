default_app_config = 'daash.front.apps.FrontConfig'
