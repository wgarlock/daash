default_app_config = 'daash.blog.apps.BlogConfig'
