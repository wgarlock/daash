default_app_config = 'daash.base.apps.BaseConfig'
