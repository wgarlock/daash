class TenantDatabaseExists(Exception):
    pass


class TenantDatabaseDoesNotExists(Exception):
    pass
