default_app_config = 'daash.tenant.apps.TenantConfig'
